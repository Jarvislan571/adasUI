package com.tencent.adasdemo;

/**
 * @author xiaojunzhou
 * @date 16/6/12
 */
public class Constants {
    public final static int CameraWidth = 1920;
    public final static int CameraHeight = 1080;

    public final static int ADAS_WIDTH = 1280;
    public final static int ADAS_HEIGHT = 720;
}
